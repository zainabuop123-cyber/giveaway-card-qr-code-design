# Giveaway Card — Original Concept Project

## Overview
A premium two-sided promotional giveaway postcard concept built around an elegant ivory, sage green, deep plum, ochre, and sand palette. The front is intentionally minimal and invitation-like; the back creates a clear conversion path with the required **Support the Production** and **Scan to Give** messaging.

## Deliverables
- `giveaway_card_front.svg` — editable front-side vector artwork.
- `giveaway_card_back.svg` — editable back-side vector artwork with a non-scannable QR placement placeholder.
- `giveaway_card_print_ready.pdf` — two-page PDF export sized to 6 × 9 inches including 0.125 inch bleed and crop marks; trim is 5.5 × 8.5 inches.
- `giveaway_card_front.png` / `giveaway_card_back.png` — high-resolution previews.
- `portfolio_board.png` — professional presentation board showing both sides.
- `print_ready.html` — source used to create the two-page PDF.

## Production notes
The SVG files are the editable source. They use live text and vector shapes so the composition can be adjusted in Illustrator, Figma, Inkscape, or another vector editor. Before commercial production, replace the QR placeholder with the final destination QR code, confirm the destination URL, convert type to outlines if required by the printer, and verify the printer’s preferred color profile and safe area.

This is an original concept project and does not represent completed client work.
